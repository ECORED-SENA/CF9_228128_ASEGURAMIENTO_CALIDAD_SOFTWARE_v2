function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6f0tTj6IQkm":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

